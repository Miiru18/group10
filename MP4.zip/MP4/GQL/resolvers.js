import {StudentList} from "../D"
import { ApolloServer } from "@apollo-server";

const typeDefs = 
type student {
    id: id,
    fisrt_name: String,
    lastName: String,
    email: String,
    student_ID: String
}

export default typeDefs