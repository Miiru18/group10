<script setup>
import router from '../routes/mainRoute'
</script>

<template>
  <header>
  </header>

  <main>
   
  </main>
</template>


